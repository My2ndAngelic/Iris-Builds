For 64-bit Linux:
Double click or
exec ./iris-mini-0.1.8_x64

For 32-bit Linux:
Double click or
exec ./iris-mini-0.1.8_x32

If not executable Right click -> Permissions -> Allow this file to run as a program

If you any problems starting Iris please write to me at: daniel@iristech.co

Daniel Georgiev - Founder of Iris :)
